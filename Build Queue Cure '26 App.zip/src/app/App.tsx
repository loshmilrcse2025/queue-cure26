import { useState, useCallback, useRef, useEffect } from "react";

type View = "landing" | "receptionist" | "patient";

interface Patient {
  id: number;
  tokenNumber: number;
  name: string;
  addedAt: string;
}

interface QueueState {
  queue: Patient[];
  currentToken: Patient | null;
  nextTokenNumber: number;
  avgConsultationTime: number;
}

const initialState: QueueState = {
  queue: [],
  currentToken: null,
  nextTokenNumber: 101,
  avgConsultationTime: 10,
};

// ── Shared store (simulates Socket.IO real-time sync in preview) ─────────────
let _store = { ...initialState };
const _listeners: Set<() => void> = new Set();
function useStore() {
  const [, forceRender] = useState(0);
  useEffect(() => {
    const cb = () => forceRender((n) => n + 1);
    _listeners.add(cb);
    return () => { _listeners.delete(cb); };
  }, []);
  return _store;
}
function dispatch(updater: (s: QueueState) => QueueState) {
  _store = updater(_store);
  _listeners.forEach((cb) => cb());
}

// ── Utility ──────────────────────────────────────────────────────────────────
function now() {
  return new Date().toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" });
}

// ── NavBar ───────────────────────────────────────────────────────────────────
function NavBar({ view, setView }: { view: View; setView: (v: View) => void }) {
  return (
    <header className="bg-card border-b border-border">
      <div className="max-w-5xl mx-auto px-6 h-14 flex items-center justify-between">
        <button
          onClick={() => setView("landing")}
          className="flex items-center gap-2 group"
        >
          <div className="w-7 h-7 rounded bg-primary flex items-center justify-center">
            <span className="text-primary-foreground text-xs font-bold" style={{ fontFamily: "'JetBrains Mono', monospace" }}>Q</span>
          </div>
          <span className="font-semibold text-foreground text-sm tracking-tight">
            Queue Cure <span className="text-primary">'26</span>
          </span>
        </button>

        {view !== "landing" && (
          <nav className="flex items-center gap-1">
            <NavPill active={view === "receptionist"} onClick={() => setView("receptionist")}>
              Receptionist
            </NavPill>
            <NavPill active={view === "patient"} onClick={() => setView("patient")}>
              Patient Room
            </NavPill>
          </nav>
        )}
      </div>
    </header>
  );
}

function NavPill({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={`px-3 py-1.5 rounded text-sm font-medium transition-colors ${
        active
          ? "bg-primary text-primary-foreground"
          : "text-muted-foreground hover:text-foreground hover:bg-muted"
      }`}
    >
      {children}
    </button>
  );
}

// ── Landing Page ─────────────────────────────────────────────────────────────
function Landing({ setView }: { setView: (v: View) => void }) {
  return (
    <main className="min-h-screen bg-background flex flex-col">
      <div className="flex-1 flex flex-col items-center justify-center px-6 py-16">
        {/* Hero */}
        <div className="text-center mb-14 max-w-xl">
          <div className="inline-flex items-center gap-2 bg-secondary text-primary text-xs font-semibold px-3 py-1 rounded-full mb-5 tracking-wide uppercase">
            <span className="w-1.5 h-1.5 rounded-full bg-primary inline-block" />
            Healthcare Queue System
          </div>
          <h1
            className="text-5xl font-bold text-foreground mb-4 leading-tight"
            style={{ fontFamily: "'Instrument Sans', sans-serif", letterSpacing: "-0.02em" }}
          >
            Queue Cure{" "}
            <span className="text-primary">'26</span>
          </h1>
          <p className="text-muted-foreground text-lg leading-relaxed">
            Streamlined patient queue management with real-time updates.
            Reduce wait-room anxiety — everyone knows exactly where they stand.
          </p>
        </div>

        {/* Role cards */}
        <div className="grid grid-cols-1 gap-4 w-full max-w-2xl sm:grid-cols-2">
          <RoleCard
            role="Receptionist"
            description="Manage the queue, add patients, set wait times, and call next tokens."
            icon="🏥"
            accent="bg-primary"
            onClick={() => setView("receptionist")}
            cta="Open Dashboard"
          />
          <RoleCard
            role="Patient"
            description="See your position in line and estimated wait time, updated in real-time."
            icon="🪑"
            accent="bg-accent"
            onClick={() => setView("patient")}
            cta="Check Your Wait"
          />
        </div>

        {/* Stats bar */}
        <div className="mt-14 flex flex-wrap justify-center gap-8">
          {[
            { label: "Tokens start at", value: "101" },
            { label: "Real-time updates", value: "Live" },
            { label: "Avg. session", value: "10 min" },
          ].map(({ label, value }) => (
            <div key={label} className="text-center">
              <div
                className="text-2xl font-bold text-primary"
                style={{ fontFamily: "'JetBrains Mono', monospace" }}
              >
                {value}
              </div>
              <div className="text-xs text-muted-foreground mt-0.5 uppercase tracking-wide">{label}</div>
            </div>
          ))}
        </div>
      </div>
    </main>
  );
}

function RoleCard({
  role, description, icon, accent, onClick, cta,
}: {
  role: string; description: string; icon: string; accent: string;
  onClick: () => void; cta: string;
}) {
  return (
    <button
      onClick={onClick}
      className="group bg-card border border-border rounded-xl p-6 text-left hover:border-primary/40 hover:shadow-lg transition-all duration-200 flex flex-col gap-4"
    >
      <div className={`w-11 h-11 ${accent} rounded-lg flex items-center justify-center text-xl`}>
        {icon}
      </div>
      <div>
        <div className="font-semibold text-foreground text-base mb-1">{role}</div>
        <p className="text-muted-foreground text-sm leading-relaxed">{description}</p>
      </div>
      <div className="flex items-center gap-1.5 text-primary text-sm font-medium mt-auto group-hover:gap-2.5 transition-all">
        {cta}
        <span>→</span>
      </div>
    </button>
  );
}

// ── Receptionist Dashboard ───────────────────────────────────────────────────
function Receptionist() {
  const store = useStore();
  const [patientName, setPatientName] = useState("");
  const [timeInput, setTimeInput] = useState(String(store.avgConsultationTime));
  const inputRef = useRef<HTMLInputElement>(null);

  const addPatient = useCallback(() => {
    const name = patientName.trim();
    if (!name) return;
    dispatch((s) => ({
      ...s,
      queue: [
        ...s.queue,
        { id: Date.now(), tokenNumber: s.nextTokenNumber, name, addedAt: now() },
      ],
      nextTokenNumber: s.nextTokenNumber + 1,
    }));
    setPatientName("");
    inputRef.current?.focus();
  }, [patientName]);

  const callNext = useCallback(() => {
    dispatch((s) => {
      if (s.queue.length === 0) return s;
      const [next, ...rest] = s.queue;
      return { ...s, queue: rest, currentToken: next };
    });
  }, []);

  const resetQueue = useCallback(() => {
    dispatch(() => ({ ...initialState }));
    setTimeInput("10");
  }, []);

  const updateTime = useCallback(() => {
    const t = parseInt(timeInput) || 10;
    dispatch((s) => ({ ...s, avgConsultationTime: t }));
  }, [timeInput]);

  return (
    <main className="min-h-screen bg-background">
      <div className="max-w-5xl mx-auto px-6 py-8 grid grid-cols-1 gap-6 lg:grid-cols-3">

        {/* Left column */}
        <div className="lg:col-span-1 flex flex-col gap-5">
          {/* Currently serving */}
          <div className="bg-primary rounded-xl p-5 text-primary-foreground">
            <div className="text-xs font-semibold uppercase tracking-widest opacity-70 mb-3">
              Now Serving
            </div>
            {store.currentToken ? (
              <>
                <div
                  className="text-5xl font-bold leading-none mb-2"
                  style={{ fontFamily: "'JetBrains Mono', monospace" }}
                >
                  {store.currentToken.tokenNumber}
                </div>
                <div className="text-sm opacity-80 font-medium">{store.currentToken.name}</div>
                <div className="text-xs opacity-50 mt-1">Called at {store.currentToken.addedAt}</div>
              </>
            ) : (
              <div className="text-3xl font-semibold opacity-40" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                — —
              </div>
            )}
          </div>

          {/* Add patient */}
          <div className="bg-card border border-border rounded-xl p-5">
            <h2 className="font-semibold text-foreground text-sm mb-3">Add Patient</h2>
            <div className="flex flex-col gap-2">
              <input
                ref={inputRef}
                type="text"
                value={patientName}
                onChange={(e) => setPatientName(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && addPatient()}
                placeholder="Patient name…"
                className="w-full bg-input-background border border-border rounded-md px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring/40"
              />
              <div className="flex items-center justify-between text-xs text-muted-foreground px-0.5">
                <span>Next token</span>
                <span
                  className="font-semibold text-primary"
                  style={{ fontFamily: "'JetBrains Mono', monospace" }}
                >
                  #{store.nextTokenNumber}
                </span>
              </div>
              <button
                onClick={addPatient}
                disabled={!patientName.trim()}
                className="w-full bg-primary text-primary-foreground rounded-md py-2 text-sm font-semibold hover:bg-accent disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              >
                Add to Queue
              </button>
            </div>
          </div>

          {/* Settings */}
          <div className="bg-card border border-border rounded-xl p-5">
            <h2 className="font-semibold text-foreground text-sm mb-3">Settings</h2>
            <label className="text-xs text-muted-foreground block mb-1.5">
              Avg. consultation time (min)
            </label>
            <div className="flex gap-2">
              <input
                type="number"
                min={1}
                max={120}
                value={timeInput}
                onChange={(e) => setTimeInput(e.target.value)}
                onBlur={updateTime}
                onKeyDown={(e) => e.key === "Enter" && updateTime()}
                className="flex-1 bg-input-background border border-border rounded-md px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring/40"
              />
              <button
                onClick={updateTime}
                className="px-3 py-2 bg-secondary text-foreground rounded-md text-sm font-medium hover:bg-muted transition-colors"
              >
                Set
              </button>
            </div>
          </div>

          {/* Actions */}
          <div className="flex flex-col gap-2">
            <button
              onClick={callNext}
              disabled={store.queue.length === 0}
              className="w-full py-3 bg-primary text-primary-foreground rounded-xl text-sm font-semibold hover:bg-accent disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
            >
              Call Next Token →
            </button>
            <button
              onClick={resetQueue}
              className="w-full py-2.5 border border-destructive/30 text-destructive rounded-xl text-sm font-medium hover:bg-destructive/5 transition-colors"
            >
              Reset Queue
            </button>
          </div>
        </div>

        {/* Right column — queue list */}
        <div className="lg:col-span-2">
          <div className="bg-card border border-border rounded-xl overflow-hidden">
            <div className="flex items-center justify-between px-5 py-4 border-b border-border">
              <h2 className="font-semibold text-foreground text-sm">Waiting Queue</h2>
              <span
                className="text-xs font-semibold bg-primary/10 text-primary px-2 py-0.5 rounded-full"
                style={{ fontFamily: "'JetBrains Mono', monospace" }}
              >
                {store.queue.length} waiting
              </span>
            </div>

            {store.queue.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-20 text-muted-foreground">
                <div className="text-4xl mb-3">🪑</div>
                <div className="text-sm font-medium">Queue is empty</div>
                <div className="text-xs mt-1 opacity-60">Add patients using the form</div>
              </div>
            ) : (
              <div className="divide-y divide-border">
                {store.queue.map((p, i) => {
                  const waitMins = (i + 1) * store.avgConsultationTime;
                  return (
                    <div key={p.id} className="flex items-center gap-4 px-5 py-3.5 hover:bg-muted/40 transition-colors">
                      <div
                        className={`w-8 h-8 rounded-md flex items-center justify-center text-xs font-bold shrink-0 ${
                          i === 0 ? "bg-primary text-primary-foreground" : "bg-secondary text-foreground"
                        }`}
                        style={{ fontFamily: "'JetBrains Mono', monospace" }}
                      >
                        {i + 1}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="font-medium text-foreground text-sm truncate">{p.name}</div>
                        <div className="text-xs text-muted-foreground">Added {p.addedAt}</div>
                      </div>
                      <div className="text-right shrink-0">
                        <div
                          className="text-sm font-bold text-foreground"
                          style={{ fontFamily: "'JetBrains Mono', monospace" }}
                        >
                          #{p.tokenNumber}
                        </div>
                        <div className="text-xs text-muted-foreground">~{waitMins} min</div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </main>
  );
}

// ── Patient Waiting Room ─────────────────────────────────────────────────────
function PatientRoom() {
  const store = useStore();
  const [myToken, setMyToken] = useState("");
  const [inputVal, setInputVal] = useState("");

  const myTokenNum = parseInt(myToken);
  const myPosition = store.queue.findIndex((p) => p.tokenNumber === myTokenNum);
  const tokensAhead = myPosition; // -1 if not found
  const isBeingServed = store.currentToken?.tokenNumber === myTokenNum;
  const alreadyCalled =
    store.currentToken !== null &&
    myTokenNum < (store.currentToken?.tokenNumber ?? 0) &&
    myPosition === -1;
  const estimatedWait =
    myPosition >= 0 ? (myPosition + 1) * store.avgConsultationTime : null;

  const checkToken = () => {
    const t = parseInt(inputVal);
    if (!isNaN(t)) setMyToken(String(t));
  };

  return (
    <main className="min-h-screen bg-background">
      <div className="max-w-3xl mx-auto px-6 py-10 flex flex-col gap-6">

        {/* Current serving banner */}
        <div className="bg-primary rounded-2xl p-8 text-center text-primary-foreground">
          <div className="text-xs font-semibold uppercase tracking-widest opacity-70 mb-3">
            Now Being Served
          </div>
          {store.currentToken ? (
            <>
              <div
                className="text-7xl font-bold leading-none mb-3"
                style={{ fontFamily: "'JetBrains Mono', monospace" }}
              >
                {store.currentToken.tokenNumber}
              </div>
              <div className="text-base opacity-75">{store.currentToken.name}</div>
            </>
          ) : (
            <div
              className="text-5xl font-semibold opacity-30"
              style={{ fontFamily: "'JetBrains Mono', monospace" }}
            >
              — —
            </div>
          )}
          <div className="mt-4 text-xs opacity-50">
            {store.queue.length} patient{store.queue.length !== 1 ? "s" : ""} waiting ·{" "}
            {store.avgConsultationTime} min avg.
          </div>
        </div>

        {/* Token lookup */}
        <div className="bg-card border border-border rounded-xl p-5">
          <h2 className="font-semibold text-foreground text-sm mb-3">Check My Token</h2>
          <div className="flex gap-2">
            <input
              type="number"
              value={inputVal}
              onChange={(e) => setInputVal(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && checkToken()}
              placeholder="Enter your token number…"
              className="flex-1 bg-input-background border border-border rounded-md px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring/40"
            />
            <button
              onClick={checkToken}
              className="px-4 py-2 bg-primary text-primary-foreground rounded-md text-sm font-semibold hover:bg-accent transition-colors"
            >
              Check
            </button>
          </div>

          {myToken && (
            <div className="mt-4">
              {isBeingServed ? (
                <StatusCard
                  color="bg-primary"
                  textColor="text-primary-foreground"
                  icon="🔔"
                  title={`Token #${myToken} — Your turn!`}
                  subtitle="Please proceed to the consultation room now."
                />
              ) : alreadyCalled ? (
                <StatusCard
                  color="bg-muted"
                  textColor="text-foreground"
                  icon="⏮"
                  title={`Token #${myToken} — Already called`}
                  subtitle="Your token was called earlier. Please check with reception."
                />
              ) : myPosition >= 0 ? (
                <div className="grid grid-cols-3 gap-3 mt-2">
                  <StatTile
                    label="Your token"
                    value={`#${myToken}`}
                    highlight={false}
                  />
                  <StatTile
                    label="Ahead of you"
                    value={String(tokensAhead)}
                    highlight={tokensAhead === 0}
                  />
                  <StatTile
                    label="Est. wait"
                    value={estimatedWait !== null ? `${estimatedWait} min` : "—"}
                    highlight={false}
                  />
                </div>
              ) : (
                <StatusCard
                  color="bg-muted"
                  textColor="text-muted-foreground"
                  icon="❓"
                  title={`Token #${myToken} not found`}
                  subtitle="This token is not in the current queue. Please verify with reception."
                />
              )}
            </div>
          )}
        </div>

        {/* Queue overview */}
        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <div className="flex items-center justify-between px-5 py-4 border-b border-border">
            <h2 className="font-semibold text-foreground text-sm">Queue Overview</h2>
            <span
              className="text-xs font-semibold bg-primary/10 text-primary px-2 py-0.5 rounded-full"
              style={{ fontFamily: "'JetBrains Mono', monospace" }}
            >
              {store.queue.length} in line
            </span>
          </div>
          {store.queue.length === 0 ? (
            <div className="py-12 text-center text-muted-foreground text-sm">
              No patients currently waiting.
            </div>
          ) : (
            <div className="divide-y divide-border">
              {store.queue.slice(0, 8).map((p, i) => (
                <div
                  key={p.id}
                  className={`flex items-center gap-4 px-5 py-3 ${
                    p.tokenNumber === myTokenNum ? "bg-secondary/60" : ""
                  }`}
                >
                  <span
                    className="text-xs text-muted-foreground w-5 text-right"
                    style={{ fontFamily: "'JetBrains Mono', monospace" }}
                  >
                    {i + 1}
                  </span>
                  <div className="flex-1 text-sm text-foreground">
                    {p.tokenNumber === myTokenNum ? (
                      <span className="font-semibold text-primary">You (#{p.tokenNumber})</span>
                    ) : (
                      <span className="text-muted-foreground">Token #{p.tokenNumber}</span>
                    )}
                  </div>
                  <span className="text-xs text-muted-foreground">
                    ~{(i + 1) * store.avgConsultationTime} min
                  </span>
                </div>
              ))}
              {store.queue.length > 8 && (
                <div className="px-5 py-2.5 text-xs text-muted-foreground">
                  + {store.queue.length - 8} more patients
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </main>
  );
}

function StatusCard({
  color, textColor, icon, title, subtitle,
}: { color: string; textColor: string; icon: string; title: string; subtitle: string }) {
  return (
    <div className={`${color} ${textColor} rounded-lg p-4 flex gap-3 items-start`}>
      <span className="text-xl leading-none">{icon}</span>
      <div>
        <div className="font-semibold text-sm">{title}</div>
        <div className="text-xs opacity-75 mt-0.5">{subtitle}</div>
      </div>
    </div>
  );
}

function StatTile({ label, value, highlight }: { label: string; value: string; highlight: boolean }) {
  return (
    <div
      className={`rounded-lg p-3 text-center border ${
        highlight ? "bg-primary/10 border-primary/20" : "bg-muted/50 border-border"
      }`}
    >
      <div
        className={`text-xl font-bold ${highlight ? "text-primary" : "text-foreground"}`}
        style={{ fontFamily: "'JetBrains Mono', monospace" }}
      >
        {value}
      </div>
      <div className="text-xs text-muted-foreground mt-0.5 uppercase tracking-wide">{label}</div>
    </div>
  );
}

// ── Root ─────────────────────────────────────────────────────────────────────
export default function App() {
  const [view, setView] = useState<View>("landing");

  return (
    <div
      className="min-h-screen bg-background text-foreground"
      style={{ fontFamily: "'Instrument Sans', sans-serif" }}
    >
      <NavBar view={view} setView={setView} />
      {view === "landing" && <Landing setView={setView} />}
      {view === "receptionist" && <Receptionist />}
      {view === "patient" && <PatientRoom />}
    </div>
  );
}
