import express from 'express';
import { createServer } from 'http';
import { Server } from 'socket.io';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer);

// Serve static files from the public directory
app.use(express.static(join(__dirname, 'public')));

// Queue state
let queue = [];
let currentToken = null;
let nextTokenNumber = 101;
let avgConsultationTime = 10; // default 10 minutes

// Socket.IO connection handling
io.on('connection', (socket) => {
  console.log('A user connected');

  // Send initial state to newly connected clients
  socket.emit('initial-state', {
    queue,
    currentToken,
    nextTokenNumber,
    avgConsultationTime
  });

  // Add patient to queue
  socket.on('add-patient', (patientName) => {
    const newPatient = {
      id: Date.now(),
      tokenNumber: nextTokenNumber,
      name: patientName,
      timestamp: new Date().toISOString()
    };
    
    queue.push(newPatient);
    nextTokenNumber++;
    
    // Broadcast updated queue to all clients
    io.emit('queue-updated', { queue, nextTokenNumber });
  });

  // Call next token
  socket.on('call-next', () => {
    if (queue.length > 0) {
      currentToken = queue.shift();
      io.emit('token-called', { currentToken, queue });
    }
  });

  // Update average consultation time
  socket.on('update-consultation-time', (time) => {
    avgConsultationTime = parseInt(time) || 10;
    io.emit('consultation-time-updated', avgConsultationTime);
  });

  // Reset queue
  socket.on('reset-queue', () => {
    queue = [];
    currentToken = null;
    nextTokenNumber = 101;
    io.emit('queue-reset', { queue, currentToken, nextTokenNumber });
  });

  socket.on('disconnect', () => {
    console.log('User disconnected');
  });
});

const PORT = process.env.PORT || 3000;
httpServer.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
